package com.goaway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GoawayApplicationTests {

    @Test
    void contextLoads() {
    }

}
