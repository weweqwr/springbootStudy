package com.goaway.entity;

public class ObsClientEntity {
    String endPoint="obs.cn-south-1.myhuaweicloud.com";
    String ak = "BLT3FQKF02NW5BA0PYWE";
    String sk = "kCFwHRccrbAmouJFERKYRv3LsON9zqDJTqmss2SF";

    public String getEndPoint() {
        return endPoint;
    }

    public void setEndPoint(String endPoint) {
        this.endPoint = endPoint;
    }

    public String getAk() {
        return ak;
    }

    public void setAk(String ak) {
        this.ak = ak;
    }

    public String getSk() {
        return sk;
    }

    public void setSk(String sk) {
        this.sk = sk;
    }
}
