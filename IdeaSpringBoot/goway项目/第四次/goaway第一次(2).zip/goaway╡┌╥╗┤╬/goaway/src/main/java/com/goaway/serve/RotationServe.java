package com.goaway.serve;

import com.goaway.entity.Gw_rotation;

import java.util.List;
import java.util.Map;

public interface RotationServe {
    //显示轮播信息
    Map<String,Object> queryRontation();
}
