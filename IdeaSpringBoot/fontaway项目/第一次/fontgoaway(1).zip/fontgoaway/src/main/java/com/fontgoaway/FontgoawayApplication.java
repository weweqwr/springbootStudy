package com.fontgoaway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FontgoawayApplication {

    public static void main(String[] args) {
        SpringApplication.run(FontgoawayApplication.class, args);
    }

}
