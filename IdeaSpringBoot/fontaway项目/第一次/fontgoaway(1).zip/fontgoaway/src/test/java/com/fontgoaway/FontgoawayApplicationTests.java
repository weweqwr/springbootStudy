package com.fontgoaway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FontgoawayApplicationTests {

    @Test
    void contextLoads() {
    }

}
